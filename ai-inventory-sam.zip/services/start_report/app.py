import json, uuid, boto3, os
from dynamodb import create_execution

sf = boto3.client("stepfunctions")

def lambda_handler(event, context):
    body = json.loads(event["body"])
    exec_id = str(uuid.uuid4())
    create_execution(exec_id, body)
    sf.start_execution(
        stateMachineArn=os.environ["STATE_MACHINE_ARN"],
        name=exec_id,
        input=json.dumps({"execution_id": exec_id, **body})
    )
    return {"statusCode": 202, "body": json.dumps({"execution_id": exec_id})}
