from aws import assume_role

def lambda_handler(event, context):
    ec2 = assume_role(event["account"], "CloudInventoryReadRole", event["region"])
    res = ec2.describe_instances()
    return {"instances": [
        {"id": i["InstanceId"], "type": i["InstanceType"], "state": i["State"]["Name"]}
        for r in res["Reservations"] for i in r["Instances"]
    ]}
