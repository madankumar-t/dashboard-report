
export function login() {
  window.location.href = import.meta.env.VITE_SSO_LOGIN_URL;
}
