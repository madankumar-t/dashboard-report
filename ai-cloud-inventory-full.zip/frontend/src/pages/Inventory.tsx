
import api from "../api/client";

export default function Inventory() {
  const load = async () => {
    const res = await api.get("/inventory/ec2?region=us-east-1&account=111111111111");
    console.log(res.data);
  };
  return <button onClick={load}>Load Inventory</button>;
}
