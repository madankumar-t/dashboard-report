
import boto3, os
from datetime import datetime

table = boto3.resource("dynamodb").Table(os.environ["EXEC_TABLE"])

def create_execution(exec_id, payload):
    table.put_item(Item={
        "execution_id": exec_id,
        "sk": "METADATA",
        "status": "RUNNING",
        "started_at": datetime.utcnow().isoformat(),
        "payload": payload
    })

def store_result(exec_id, result):
    table.put_item(Item={
        "execution_id": exec_id,
        "sk": "RESULT",
        **result
    })
